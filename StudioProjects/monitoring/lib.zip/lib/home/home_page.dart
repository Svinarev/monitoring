import 'dart:async';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:monitoring/home/components/map/map.dart';
import 'package:video_player/video_player.dart';
import '../global/global.dart';
import 'components/SideBar/side_bar.dart';
import 'components/SideBar/side_bar_function.dart';
import 'components/header/header.dart';
import 'components/map/DispensingContainer/dispensing_container.dart';
import 'components/map/map_global.dart';
import 'components/right_side_menu/right_side_menu.dart';

///Домашняя 

bool buttonTest = false;

StreamController homeController = StreamController.broadcast();


class HomePage extends StatefulWidget {
  const HomePage({Key? key, required this.stream}) : super(key: key);

  final Stream stream;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {



  ///Функция расширения карты
  mapExtension(){
    if(addEndHeader == menuTest && addEndHeader == animationTrue) {
      addEndHeader = !addEndHeader;
      menuTest = !menuTest;
      animationTrue = !animationTrue;
    } else {
      addEndHeader = !addEndHeader;
      menuTest = addEndHeader;
    }
  }
  timerForCars(){
    Timer.periodic(const Duration(seconds: 5), (timer) async{
      await getListAuto();
    });
  }

  @override
  void initState() {
    super.initState();
    timerForCars();
    widget.stream.listen((event) {
      if(event == 'header') {
        mapExtension();
        setState(() {});
      }
      else if(event == 'stateCars'){
        setState(() {});
      }
      else {
        testVideo(event);
        _createChewieController();
        url = event;
      }
    });
  }

  @override
  void dispose() {
    ///===
    _videoPlayerController1.dispose();
    _chewieController?.dispose();
    ///===
    super.dispose();

  }

  ///Видео Плеер ===========================================================

  testVideo(String name_video){
    _videoPlayerController1 = VideoPlayerController.network(
        'http://$myId:$myPort/' + name_video
    )
      ..initialize().then((_) {
        _videoPlayerController1.seekTo(_currentPosition);
        setState(() {});
      });
  }


  Duration _currentPosition = Duration.zero;
  bool _isPlaying = false;
  String ? url;

  void _reInitControllers() {
    _chewieController?.removeListener(_reInitListener);
    _currentPosition = _videoPlayerController1.value.position;
    _isPlaying = _chewieController!.isPlaying;
    testVideo(url!);
    _createChewieController();
  }

  void _reInitListener() {
    if (!_chewieController!.isFullScreen) {
      _reInitControllers();
    }
  }

  late VideoPlayerController _videoPlayerController1;
  ChewieController? _chewieController;



  void _createChewieController() {
    _chewieController = ChewieController(
      videoPlayerController: _videoPlayerController1,
    )
      ..addListener(_reInitListener);
    if(_isPlaying){
      _chewieController!.play();
    }
    ;
  }

  Future<void> toggleVideo() async {
    await _videoPlayerController1.pause();
  }
  ///=======================================================================




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ///Header
              Visibility(
                visible: addEndHeader,
                  child: Header()),
              ///Боковое меню с лева
              Expanded(
                child: Row(
                  children: [
                    if(menuTest)
                    SideBar(
                      stream: controllerSideBar.stream,
                    ),
                    ///Карта
                    Expanded(
                        child: MyMap(steam: controllerMap.stream,)),
                  ],
                ),
              ),
            ],
          ),
          ///Боковое меню с права
          Positioned(
            right: 20,
            top: 80,
            child: RightSideMenu(),
          ),
          ///Видеоплеер
          if(buttonTest)
            Center(
              child: Stack(
                children: [
                  Positioned(
                    left: position.dx,
                    top: position.dy,
                    child: Draggable(
                      feedback: Container(
                        width: 500,
                        height: 280,
                        color: Colors.grey.withOpacity(0.5),
                      ),
                      onDragEnd: (details) => setState(() {
                        position = details.offset;
                        if(_isPlaying){
                          _chewieController!.play();
                        }
                      }),
                      child: Stack(
                        children: [
                          Container(
                            width: 500,
                            height: 280,
                            child: Center(
                              child: _chewieController != null &&
                                  _chewieController!
                                      .videoPlayerController.value.isInitialized
                                  ? Chewie(
                                controller: _chewieController!,
                              )
                              ///Загрузка
                                  : Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  CircularProgressIndicator(),
                                  SizedBox(height: 20),
                                  Text('Loading'),
                                ],
                              ),
                            ),
                          ),
                          ///иконка закрыть
                          Positioned(
                            top: 0,
                            right: 0,
                            child: IconButton(
                              onPressed: () {
                                buttonTest = false;
                                setState(() {});
                              },
                              icon: Icon(Icons.highlight_remove, color: Colors.white,),
                            ),),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
Offset position = Offset(200, 200);
}

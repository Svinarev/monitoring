import 'package:flutter/material.dart';
import 'package:monitoring/global/global.dart';
import '../../../my_icon_icons.dart';
import '../../home_page.dart';
import '../SideBar/side_bar_function.dart';
import '../map/map_global.dart';

///Кнопки иконки с права

class RightSideMenu extends StatefulWidget {
  const RightSideMenu({
    Key? key,
  }) : super(key: key);

  @override
  State<RightSideMenu> createState() => _RightSideMenuState();
}

class _RightSideMenuState extends State<RightSideMenu> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            ///Слои карт
            ButtonIcons(
              icon: Icons.layers_outlined,
              press: () {},
              helpMessage: 'Выбрать вид карты',
            ),

            ///zoom +
            ButtonIcons(
              icon: Icons.add_circle_outline,
              press: () {
                controllerMap.add(true);
              },
              helpMessage: 'Приблизить',
            ),

            ///zoom -
            ButtonIcons(
              icon: Icons.remove_circle_outline_outlined,
              press: () {
                controllerMap.add(false);
              },
              helpMessage: 'Отдалить',
            ),

            ///Показать только карту на весь экран
            ButtonIcons(
              icon: Icons.zoom_out_map,
              press: () {
                ///
                homeController.add('header');
              },
              helpMessage: 'Карта на весь экран',
            ),

            ///Скриншот экрана
            ButtonIcons(
              icon: Icons.camera_alt_outlined,
              press: () {},
              helpMessage: 'Снимок экрана',
            ),
          ],
        ),
        SizedBox(height: 40),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            ///Уведомления
            ButtonIcons(
              icon: Icons.notifications_none,
              press: () {},
              helpMessage: 'Уведомления',
            ),

            ///Маршрут по дате
            ButtonIcons(
              icon: MyIcon.route,
              press: () {
                getTestPuth();
              },
              helpMessage: 'Маршрут машины',
              colorBotton: offDateOff ? Color(0xFF6FA073) : Colors.grey,
            ),

            ///центровка всех точек
            ButtonIcons(
              icon: Icons.filter_center_focus,
              press: () {
                controllerMap.add(allCarsCoordinates);
              },
              helpMessage: 'центровка всех точек',
            ),

            ///выбрать определенный радиус и посмотреть манины
            ButtonIcons(
              icon: Icons.track_changes,
              press: () {},
              helpMessage: 'Вибрать радиус',
            ),
          ],
        ),
        SizedBox(height: 40),
      ],
    );
  }
}

///Кнопка иконка
class ButtonIcons extends StatefulWidget {
  IconData icon;
  var press;
  String? helpMessage;
  Color colorBotton;

  ButtonIcons(
      {Key? key,
      required this.icon,
      required this.press,
      this.helpMessage,
      this.colorBotton = Colors.grey})
      : super(key: key);

  @override
  State<ButtonIcons> createState() => _ButtonIconsState();
}

class _ButtonIconsState extends State<ButtonIcons> {
  bool isHover = false;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (isHover && widget.helpMessage != null)
          Container(
            padding: EdgeInsets.all(5.0),
            decoration: BoxDecoration(
                color: Colors.grey.shade800.withOpacity(0.8),
                borderRadius: BorderRadius.circular(5)),
            child: Text(
              widget.helpMessage!,
              style: TextStyle(color: Colors.white, fontSize: 12),
            ),
          ),
        InkWell(
          onTap: widget.press,
          onHover: (val) {
            setState(() {
              isHover = val;
            });
          },
          child: Padding(
            padding: const EdgeInsets.all(5.0),
            child: Container(
              width: 35,
              height: 35,
              decoration: BoxDecoration(
                color: isHover ? Colors.blue[300] : widget.colorBotton,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Center(
                  child: Icon(
                widget.icon,
                size: 18,
                color: Colors.white,
              )),
            ),
          ),
        ),
      ],
    );
  }
}

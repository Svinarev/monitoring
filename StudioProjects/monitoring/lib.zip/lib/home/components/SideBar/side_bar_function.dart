import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:monitoring/home/components/SideBar/side_bar.dart';
import 'package:monitoring/home/components/SideBar/side_bar_list.dart';
import '../../../global/global.dart';
import '../../home_page.dart';
import '../map/map_global.dart';

///Функции Side Bar

///Функция создание всех маркуров на карте ===============================
createAllMarkerCar(List allCars) {
  for (int i = 0; i < allCars.length; i++) {
    if (allCars[i].length > 5) {
      allCarsMarker.add(Marker(
          point: LatLng(double.parse(allCars[i][4].split(',').first),
              double.parse(allCars[i][4].split(',').last)),
          builder: (BuildContext context) {
            return Icon(
              Icons.car_rental,
              size: 30,
              color: Colors.orange,
            );
          }));
      allCarsCoordinates.add(LatLng(
          double.parse(allCars[i][4].split(', ').first),
          double.parse(allCars[i][4].split(', ').last)));
    }
    // controllerMap.add(allCarsMarker);
  }
}
///=======================================================================


///Функция получения списка всех машин ===================================
getListAuto() async {
  var response = await http.post(Uri.parse("http://$myId:$myPort/all_id_car"),
      headers: {
        "Content-Type": "application/json; charset=utf-8",
      },
      body: json.encode(
        {'id_car': "123"},
      ));
  var vovas = jsonDecode(response.body);
  source = vovas;
  print(source);
  await createAllMarkerCar(source!);
  controllerSideBar.add([source, 'cars']);
  homeController.add('stateCars');
}
///=======================================================================


///Функция получения списка всех машин ===================================
getListAutoTest() async {
  var response =
      await http.post(Uri.parse("http://$myId:$myPort/all_about_one_car"),
          headers: {
            "Content-Type": "application/json; charset=utf-8",
          },
          body: json.encode(
            {
              "id_car": "1014",
              "date_start": "2022-02-07 00:00:01",
              "date_end": "2022-02-09 00:00:00"
            },
          ));
  var vovas = jsonDecode(response.body);
  getListTest = vovas;
  print(getListTest);
}
///=======================================================================

///Функция получения списка обьектов =====================================
getObject() async {
  var response =
      await http.post(Uri.parse("http://$myId:$myPort/select_objects"),
          headers: {
            "Content-Type": "application/json; charset=utf-8",
          },
          body: json.encode(
            {'id_car': "123"},
          ));
  var vovas = jsonDecode(response.body);
  listObject = vovas;
  print(listObject);
  for (var i = 0; i < listObject!.length; i++) {
    pointsObject.add(Marker(
        point: LatLng(double.parse(listObject![i][1].split(',').first),
            double.parse(listObject![i][1].split(',').last)),
        builder: (BuildContext context) {
          return InkWell(
              onTap: () {},
              child: Icon(
                Icons.circle,
                size: 20,
                color: Colors.red,
              ));
        }));
  }
  controllerMap.add(pointsObject);
}
///=======================================================================


///Функция получения списка точек с видео ================================
String colorsIcon = '';

getVideoPoint() async {
  var response =
      await http.post(Uri.parse("http://$myId:$myPort/video_on_date"),
          headers: {
            "Content-Type": "application/json; charset=utf-8",
          },
          body: json.encode(
            {
              "id_car": "1020",
              "date_start": "2022-02-21 00:00:01",
              "date_end": "2022-02-22 00:00:00"
            },
          ));
  var vovas = jsonDecode(response.body);
  videoPoint = vovas;
  print(videoPoint);
  for (var i = 0; i < videoPoint[1].length; i++) {
    pointsObjectMap.add(Marker(
        point: LatLng(double.parse(videoPoint[1][i][0].split(',').first),
            double.parse(videoPoint[1][i][0].split(',').last)),
        builder: (BuildContext context) {
          return
            InkWell(
              onTap: () {
                buttonTest = true;
                homeController.add(videoPoint[1][i][1]);
              },
              child: colorsIcon == videoPoint[1][i][1]
                  ? Icon(
                      Icons.videocam,
                      size: 30,
                      color: Colors.red,
                    )
                  : Icon(
                      Icons.videocam,
                      size: 22,
                      color: Colors.blueGrey,
                    ));
        }));
  }
  controllerMap.add(pointsObjectMap);
}
///=======================================================================


///Функция получения точек для отображения пути на карте =================
var testPuth;
List<LatLng> pointTestPath = [];

getTestPuth() async {
  var response = await http.post(Uri.parse("http://$myId:$myPort/way"),
      headers: {
        "Content-Type": "application/json; charset=utf-8",
      },
      body: json.encode(
        {
          "id_car": "1020",
          "date_start": "2022-02-21 00:00:01",
          "date_end": "2022-02-22 00:00:00",
        },
      ));
  var vovas = jsonDecode(response.body);
  testPuth = vovas;
  print(testPuth);
  for (var i = 0; i < testPuth!.length; i++) {
    if(RegExp(r"(_+)").firstMatch(testPuth![i][0]) == null)
    pointTestPath.add(
        LatLng(double.parse(testPuth![i][0].split(', ').first),
            double.parse(testPuth![i][0].split(', ').last)),

    );}
  controllerMap.add('pointTestPath');
}
///=======================================================================

import 'package:video_player/video_player.dart';
import 'package:flutter/material.dart';

///VideoPlayer


class VideoApp extends StatefulWidget {
  @override
  _VideoAppState createState() => _VideoAppState();
}

class _VideoAppState extends State<VideoApp> {
  late VideoPlayerController _controller;
  late Duration videoLength;
  late Duration videoPosition;
  double volume = 0.5;
  bool zoomVideo = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.network(
        'https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4')
      ..addListener(() => setState(() {
            videoPosition = _controller.value.position;
          }))
      ..initialize().then((_) {
        setState(() {
          videoLength = _controller.value.duration;
        });
      });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Video Demo',
      home: Scaffold(
        body: Center(
          child: Stack(
            children: [
              zoomVideo == true ? Container(
                color: Colors.grey[200],
                child: Column(
                  children: [
                    if (_controller.value.isInitialized) ...[
                      ///Размер видео в соотнтшении с экраном
                      Expanded(
                        flex: 10,
                        child: AspectRatio(
                            aspectRatio: _controller.value.aspectRatio,
                            child:  VideoPlayer(_controller)),
                      ),
                      ///Индикатор видео
                      VideoProgressIndicator(
                        _controller,
                        allowScrubbing: true,
                        colors: VideoProgressColors(playedColor: Colors.red),
                      ),
                      ///Кнопки Play Volume Replay На весь экран
                      Expanded(
                        flex: 1,
                        child: Row(
                          children: [
                            IconButton(
                              onPressed: () {
                                setState(() {
                                  _controller.value.isPlaying
                                      ? _controller.pause()
                                      : _controller.play();
                                });
                              },
                              icon: Icon(
                                _controller.value.isPlaying
                                    ? Icons.pause
                                    : Icons.play_arrow,
                                size: 25,
                              ),
                            ),
                            Text(
                                '${convertDuration(videoPosition)} / ${convertDuration(videoLength)}'),
                            SizedBox(width: 10),
                            Icon(animatedVolumeIcon(volume)),
                            Slider(
                                value: volume,
                                min: 0,
                                max: 1,
                                onChanged: (changedVolume) {
                                  setState(() {
                                    volume = changedVolume;
                                    _controller.setVolume(changedVolume);
                                  });
                                }),
                            Spacer(),
                            IconButton(
                                onPressed: () {
                                  _controller.setLooping(!_controller.value.isLooping);
                                },
                                icon: Icon(
                                  Icons.loop,
                                  color: _controller.value.isLooping
                                      ? Colors.green
                                      : Colors.grey,
                                )),
                            SizedBox(width: 10),
                            IconButton(onPressed: (){
                              zoomVideo = !zoomVideo;
                              setState(() {});
                              print(zoomVideo);
                            }, icon: Icon(zoomVideo == true ? Icons.fullscreen_exit_rounded : Icons.fullscreen,)),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ) :
              Container(
                color: Colors.grey[200],
                width: 600,
                height: 450,
                child: Column(
                  children: [
                    if (_controller.value.isInitialized) ...[
                      ///Размер видео в соотнтшении с экраном
                      AspectRatio(
                          aspectRatio: _controller.value.aspectRatio,
                          child:  VideoPlayer(_controller)),
                      ///Индикатор видео
                      VideoProgressIndicator(
                        _controller,
                        allowScrubbing: true,
                        colors: VideoProgressColors(playedColor: Colors.red),
                      ),
                      ///Кнопки Play Volume Replay На весь экран
                      Row(
                        children: [
                          IconButton(
                            onPressed: () {
                              setState(() {
                                _controller.value.isPlaying
                                    ? _controller.pause()
                                    : _controller.play();
                              });
                            },
                            icon: Icon(
                              _controller.value.isPlaying
                                  ? Icons.pause
                                  : Icons.play_arrow,
                              size: 25,
                            ),
                          ),
                          Text(
                              '${convertDuration(videoPosition)} / ${convertDuration(videoLength)}'),
                          SizedBox(width: 10),
                          Icon(animatedVolumeIcon(volume)),
                          Slider(
                              value: volume,
                              min: 0,
                              max: 1,
                              onChanged: (changedVolume) {
                                setState(() {
                                  volume = changedVolume;
                                  _controller.setVolume(changedVolume);
                                });
                              }),
                          Spacer(),
                          IconButton(
                              onPressed: () {
                                _controller.setLooping(!_controller.value.isLooping);
                              },
                              icon: Icon(
                                Icons.loop,
                                color: _controller.value.isLooping
                                    ? Colors.green
                                    : Colors.grey,
                              )),
                          SizedBox(width: 10),
                          IconButton(onPressed: (){
                            zoomVideo = !zoomVideo;
                            setState(() {});
                            print(zoomVideo);
                          }, icon: Icon(zoomVideo == true ? Icons.fullscreen_exit_rounded : Icons.fullscreen,)),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              // Positioned(
              //   top: 0,
              //     right: 0,
              //     child: IconButton(onPressed: (){},icon: Icon(Icons.cancel_outlined,color: Colors.white,),))
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }

  String convertDuration(Duration duration) {
    final parsedMinutes = duration.inMinutes % 60;

    final minutes =
        parsedMinutes < 10 ? '0$parsedMinutes' : parsedMinutes.toString();

    final parsedSecond = duration.inSeconds % 60;

    final seconds =
        parsedSecond < 10 ? '0$parsedSecond' : parsedSecond.toString();
    return '$minutes : $seconds';
  }

  IconData animatedVolumeIcon(double volume) {
    if (volume == 0)
      return Icons.volume_mute;
    else if (volume < 0.5)
      return Icons.volume_down;
    else
      return Icons.volume_up;
  }
}


///===============================
//
//
// import 'package:flick_video_player/flick_video_player.dart';
//
//
// class SamplePlayer extends StatefulWidget {
//   SamplePlayer({Key? key}) : super(key: key);
//
//   @override
//   _SamplePlayerState createState() => _SamplePlayerState();
// }
//
// class _SamplePlayerState extends State<SamplePlayer> {
//   late FlickManager flickManager;
//   @override
//   void initState() {
//     super.initState();
//     flickManager = FlickManager(
//       videoPlayerController:
//       VideoPlayerController.network("https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4"),
//     );
//   }
//
//   @override
//   void dispose() {
//     flickManager.dispose();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       width: 500,
//       height: 500,
//       child: FlickVideoPlayer(
//           flickManager: flickManager,
//       ),
//     );
//   }
// }
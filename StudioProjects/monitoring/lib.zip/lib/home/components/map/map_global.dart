import 'dart:async';

///переменные карты

StreamController controllerMap = StreamController.broadcast();
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:monitoring/home/components/SideBar/side_bar.dart';
import 'package:monitoring/home/components/map/map_global.dart';
import 'package:monitoring/home/home_page.dart';
import '../../../global/global.dart';
import 'package:latlong2/latlong.dart';

///Ячейка с данными о машине


class CellCar extends StatefulWidget {
  CellCar({
    Key? key,
    required this.num,
    required this.model,
    required this.id,
    this.checkBox = false,
    this.coordinates,
    this.km = 0,
    this.time = '',
    this.fuel = '-',
  }) : super(key: key);
  String num;
  String model;
  String fuel;
  int km;
  int id;
  bool checkBox;
  String time;
  LatLng ? coordinates;

  @override
  State<CellCar> createState() => _CellCarState();
}

class _CellCarState extends State<CellCar> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){
        selectCar = [widget.id,widget.coordinates];
        controllerSideBar.add(selectCar);
        controllerMap.add(widget.coordinates);
        print("нажата: ${widget.model} ${widget.num}");
        print("${widget.id}");
        offDateOff = true;
        homeController.add('stateCars');
      },
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(5.0),
          color: selectCar != null &&  selectCar![0] == widget.id ? Colors.grey[350] : Colors.white,
        ),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Row(
            children: [
              Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.red, width: 2.0),
                ),
                height: 50.0,
                width: 50.0,
                child: Image.asset(
                  'img/3.png',
                  color: Colors.red,
                ),
              ),
              const SizedBox(
                width: 8.0,
              ),
              Expanded(
                child: Column(
                  children: [
                    Row(
                      children: [
                        Text(widget.model, style: TextStyle(fontWeight: FontWeight.bold),),
                        SizedBox(width: 8.0,),
                        Text(widget.num, style: TextStyle(fontWeight: FontWeight.bold)),
                        Spacer(),
                        SizedBox(
                          width: 24,
                          height: 24,
                          child: Checkbox(
                              value: widget.checkBox, onChanged: (val){
                            widget.checkBox = val!;
                            setState(() {});
                            widget.checkBox ?
                            reportList.add(widget.id) : reportList.remove(widget.id);
                            print(reportList);
                          }),
                        )
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.local_gas_station_outlined, size: 18.0,color: Colors.orangeAccent,),
                            SizedBox(width: 5.0),
                            Text(widget.fuel),
                          ],
                        ),
                        Row(
                          children: [
                            Icon(Icons.speed, size: 18.0,color: Colors.redAccent,),
                            SizedBox(width: 5.0),
                            Text('${widget.km} км/ч'),
                          ],
                        ),
                        Row(
                          children: [
                            Icon(Icons.access_time, size: 18.0,color: Colors.lightBlueAccent,),
                            SizedBox(width: 5.0),
                            Text(widget.time.isNotEmpty ?  DateFormat('HH:mm').format(DateTime.parse(widget.time)) : '-'),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}